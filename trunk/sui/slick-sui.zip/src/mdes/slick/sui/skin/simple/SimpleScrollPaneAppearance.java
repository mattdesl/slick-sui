/*
 * SimpleContainerAppearance.java
 *
 * Created on November 7, 2007, 8:17 PM
 */

package mdes.slick.sui.skin.simple;

import mdes.slick.sui.*;
import mdes.slick.sui.skin.*;
import mdes.slick.sui.skin.SuiSkin;
import mdes.slick.sui.SuiTheme;
import org.newdawn.slick.*;
import org.newdawn.slick.gui.*;

/**
 *
 * @author davedes
 */
public class SimpleScrollPaneAppearance extends SimpleContainerAppearance {
    
}
