/*
 * UIResource.java
 *
 * Created on June 23, 2007, 2:32 PM
 */

package mdes.slick.sui.skin;

/**
 *
 * @author davedes
 */
public interface UIResource {
    
}
