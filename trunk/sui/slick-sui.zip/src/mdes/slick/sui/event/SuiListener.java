package mdes.slick.sui.event;

import java.util.EventListener;

/**
 * A tagging interface which all SuiListeners should extend.
 *
 * @author davedes
 * @since b.0.2
 */
public interface SuiListener extends EventListener {
}
